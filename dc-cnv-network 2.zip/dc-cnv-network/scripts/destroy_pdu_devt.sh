#!/usr/bin/env bash
# Parameters
ENVIRONMENT="devt"
SUBSCRIPTION_NAME="dc-cnv-$ENVIRONMENT"

# Login to Azure Subscription
echo
echo "Logging in to Azure Subscription"
az login >/dev/null
az account set --subscription "Cloud Services Shared Serv Dev"
echo "Logged in to Azure Subscription successfully"

# Login via Service Principal
echo
echo "Logging in via Service Principal"
SPN_APP_ID=$(az keyvault secret show --vault-name "kv-dwp-cds-dev-ss" --name "prdSsDeploymentspnAppId" --query value | sed -e 's/^"//' -e 's/"$//')
SPN_CLIENT_SECRET=$(az keyvault secret show --vault-name "kv-dwp-cds-dev-ss" --name "prdSsDeploymentspnClientSecret" --query value | sed -e 's/^"//' -e 's/"$//')
PAT_TOKEN=$(az keyvault secret show --vault-name "kv-dwp-cds-dev-ss" --name "prdSsDeploymentSpnPAT" --query value | sed -e 's/^"//' -e 's/"$//')
az login --service-principal -u $SPN_APP_ID -p $SPN_CLIENT_SECRET --tenant "96f1f6e9-1057-4117-ac28-80cdfe86f8c3" >/dev/null
az account set --subscription $SUBSCRIPTION_NAME
echo "Logged in via Service Principal Successfully"

# Create Terraform State Storage Account
DIR="$(cut -d'-' -f1 <<<$SUBSCRIPTION_NAME)"
BUSINESS_UNIT="$(cut -d'-' -f2 <<<$SUBSCRIPTION_NAME)"
ENV="$(cut -d'-' -f3 <<<$SUBSCRIPTION_NAME)"
STORAGE_ACCOUNT_NAME=$(echo "struks"$ENV$DIR$BUSINESS_UNIT"tfstate" | tr '[:upper:]' '[:lower:]')
RESOURCE_GROUP_NAME=$(echo "rg-uks-$ENV-$DIR-$BUSINESS_UNIT-tfstate" | tr '[:upper:]' '[:lower:]')

if az storage account show --name $STORAGE_ACCOUNT_NAME --resource-group $RESOURCE_GROUP_NAME >/dev/null; then
    echo
    echo "Terraform State Storage Account Already Exists"
else
    echo
    echo "Creating Terraform State Storage Account"

    # Create Resource Group
    az group create --name $RESOURCE_GROUP_NAME --location "uksouth"

    # Lock Resource Group
    az lock create --lock-type "CanNotDelete" --name "$RESOURCE_GROUP_NAME-Lock" --resource-group $RESOURCE_GROUP_NAME

    # Create Storage Account
    az storage account create --name $STORAGE_ACCOUNT_NAME --resource-group $RESOURCE_GROUP_NAME \
        --kind "StorageV2" \
        --access-tier "Cool" \
        --sku "Standard_ZRS" \
        --https-only "true" \
        --location "uksouth"

    # Create Container
    az storage container create --name "tfstate" --account-name $STORAGE_ACCOUNT_NAME

    # Enable Soft Delete
    az storage blob service-properties delete-policy update --days-retained 7 --account-name $STORAGE_ACCOUNT_NAME --enable true
    echo "Terraform State Storage Account Created Successfully"
fi

# Set Terraform Environment Variables
export ARM_CLIENT_ID=$SPN_APP_ID
export ARM_CLIENT_SECRET=$SPN_CLIENT_SECRET
export ARM_SUBSCRIPTION_ID=$(az account show --query id | sed -e 's/^"//' -e 's/"$//')
export ARM_TENANT_ID=$(az account show --query tenantId | sed -e 's/^"//' -e 's/"$//')
export AZDO_PERSONAL_ACCESS_TOKEN=$PAT_TOKEN
export AZDO_ORG_SERVICE_URL=https://dev.azure.com/dwpgovuk
az account show

# Update Terraform Version

cd ..
terraform -v
TF_VERSION=$(cat .tf_version | awk '{$1=$1};1')
rm /usr/local/bin/terraform
wget https://releases.hashicorp.com/terraform/${TF_VERSION}/terraform_${TF_VERSION}_linux_amd64.zip --no-check-certificate && \
    unzip ./terraform_${TF_VERSION}_linux_amd64.zip -d /usr/local/bin/
rm ./terraform_${TF_VERSION}_linux_amd64.zip
terraform -v

cd terraform/

echo "Initialising Terraform Deployment"
if [ -d ".terraform" ]; then rm -rf .terraform; fi
terraform init -backend-config=./backend_config/$ENVIRONMENT.conf
echo
terraform workspace new $ENVIRONMENT &>/dev/null
terraform workspace select $ENVIRONMENT &>/dev/null
echo $(terraform workspace show)
# Deploy Terraform Solution
echo

terraform plan -destroy
echo

terraform destroy -target=azurerm_policy_assignment.policy_assignment_deny_subnetwithoutnsg --auto-approve
terraform destroy -target=azurerm_log_analytics_linked_service.oms_linked_service_dwp --auto-approve
terraform destroy --auto-approve

echo $PWD
echo "workspace list:"
echo "$(terraform workspace list)"
echo "workspace show: $(terraform workspace show)"
echo
echo "Deleting Network Watcher Resource Group"
az group delete -n NetworkWatcherRG -y
echo "Cleaning Up Security Centre"
az security contact delete --name default
az security contact delete --name default2
echo "usually you need to run thise twice, as some components don't delete first time due to dependencies"
