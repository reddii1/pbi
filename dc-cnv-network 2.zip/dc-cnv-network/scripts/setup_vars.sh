#####################################
## RUN ONCE TO CONFIGURE VARIABLES ##
#####################################

# Read in variables
# Switching to files-to-copy directory
cd ..
# Capturing PDU variable
read -p "enter PDU lower case short name (eg ts-hcs, dw-ccs): " PDU
# Capturing address spaces variable
read -p "enter the 3rd octet of the address spaces (all envs share the same, 10.105.232.0/23 it would be 232): " CIDR_THIRD_OCTET
# Capturing SBOX spare address space variable
read -p "enter the 3rd octet of SANDBOX SPARE address spaces (192.168.124.0/25 it would be 124): " CIDR_SPARE_SBOX
# Capturing DEVT spare address space variable
read -p "enter the 3rd octet of DEVT SPARE address spaces (10.87.235.0/25 it would be 235): " CIDR_SPARE_DEVT

### INFO ###
# see readme.md
##################

# Calculated Variables
# Validating PDU variable
echo $PDU
# Converting $PDU variable from lower to upper case
PDU_UPPER=$(echo $PDU | tr '[:lower:]' '[:upper:]')
# Combining $PDU variable
PDU_COMBINED=$(echo $PDU | sed -e 's/-//')
# Extracting SBOX subscription ID
SUBSCRIPTION_ID_SBOX=$(az account show -s $PDU-sbox --query id)
# Extracting DEVT subscription ID
SUBSCRIPTION_ID_DEVT=$(az account show -s $PDU-devt --query id)
# Extracting TEST subscription ID
SUBSCRIPTION_ID_TEST=$(az account show -s $PDU-test --query id)
# Extracting STAG subscription ID
SUBSCRIPTION_ID_STAG=$(az account show -s $PDU-stag --query id)
# Extracting PROD subscription ID
SUBSCRIPTION_ID_PROD=$(az account show -s $PDU-prod --query id)
# Converting DEVT spare address space variable
CIDR_SPARE_TEST=$(($CIDR_SPARE_DEVT - 1))
# Converting STAG spare address space variable
CIDR_SPARE_STAG=$(($CIDR_SPARE_DEVT - 2))
# Converting PROD spare address space variable
CIDR_SPARE_PROD=$(($CIDR_SPARE_DEVT - 3))
# Converting address space variable
SUBNET02_CIDR_THIRD_OCTET=$(($CIDR_THIRD_OCTET + 1))
# Validating $PDU_UPPER variable
echo $PDU_UPPER
# Validating $PDU_COMBINED variable
echo $PDU_COMBINED
# Validating SBOX subscription ID
echo "Sandbox: $SUBSCRIPTION_ID_SBOX"
# Validating DEVT subscription ID
echo "Development:  $SUBSCRIPTION_ID_DEVT"
# Validating TEST subscription ID
echo "Test:  $SUBSCRIPTION_ID_TEST"
# Validating STAG subscription ID
echo "Staging:  $SUBSCRIPTION_ID_STAG"
# Validating PROD subscription ID
echo "Production:  $SUBSCRIPTION_ID_PROD"
# Validating address spaces
echo "CIDR_THIRD_OCTET: $CIDR_THIRD_OCTET"
# Validating SBOX spare address space
echo "CIDR_SPARE_SBOX: $CIDR_SPARE_SBOX"
# Validating DEVT spare address space
echo "CIDR_SPARE_DEVT: $CIDR_SPARE_DEVT"
# Validating TEST spare address space
echo "CIDR_SPARE_TEST: $CIDR_SPARE_TEST"
# Validating STAG spare address space
echo "CIDR_SPARE_STAG: $CIDR_SPARE_STAG"
# Validating PROD spare address space
echo "CIDR_SPARE_PROD: $CIDR_SPARE_PROD"
# Validating address space
echo "SUBNET02_CIDR_THIRD_OCTET: $SUBNET02_CIDR_THIRD_OCTET"

# SED commands to update all relevant files with variable outputs
find . -type f -name "*.yml" -exec sed -i -e "s/dc-cnv/$PDU/g" {} +
find . -type f -name "*.yaml" -exec sed -i -e "s/{{ PDU_UPPER }}/$PDU_UPPER/g" {} +
find . -type f -name "*.sh" -exec sed -i -e "s/dc-cnv/$PDU/g" {} +
find . -type f -name "*.conf" -exec sed -i -e "s/dc-cnv/$PDU/g" {} +
find . -type f -name "*.conf" -exec sed -i -e "s/{{ PDU_COMBINED }}/$PDU_COMBINED/g" {} +
find . -type f -name "*.md" -exec sed -i -e "s/dc-cnv/$PDU/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/dc-cnv/$PDU/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ SUBSCRIPTION_ID_SBOX }}/$SUBSCRIPTION_ID_SBOX/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ SUBSCRIPTION_ID_DEVT }}/$SUBSCRIPTION_ID_DEVT/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ SUBSCRIPTION_ID_TEST }}/$SUBSCRIPTION_ID_TEST/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ SUBSCRIPTION_ID_STAG }}/$SUBSCRIPTION_ID_STAG/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ SUBSCRIPTION_ID_PROD }}/$SUBSCRIPTION_ID_PROD/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ CIDR_THIRD_OCTET }}/$CIDR_THIRD_OCTET/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ CIDR_SPARE_SBOX }}/$CIDR_SPARE_SBOX/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ CIDR_SPARE_DEVT }}/$CIDR_SPARE_DEVT/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ CIDR_SPARE_TEST }}/$CIDR_SPARE_TEST/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ CIDR_SPARE_STAG }}/$CIDR_SPARE_STAG/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ CIDR_SPARE_PROD }}/$CIDR_SPARE_PROD/g" {} +
find . -type f -name "*.tfvars" -exec sed -i -e "s/{{ SUBNET02_CIDR_THIRD_OCTET }}/$SUBNET02_CIDR_THIRD_OCTET/g" {} +
find . -type f -name "*.yml" -exec sed -i -e "s/{{ CIDR_THIRD_OCTET }}/$CIDR_THIRD_OCTET/g" {} +
find . -type f -name "*.yml" -exec sed -i -e "s/{{ CIDR_SPARE_SBOX }}/$CIDR_SPARE_SBOX/g" {} +
find . -type f -name "*.yml" -exec sed -i -e "s/{{ CIDR_SPARE_DEVT }}/$CIDR_SPARE_DEVT/g" {} +
find . -type f -name "*.yml" -exec sed -i -e "s/{{ CIDR_SPARE_TEST }}/$CIDR_SPARE_TEST/g" {} +
find . -type f -name "*.yml" -exec sed -i -e "s/{{ CIDR_SPARE_STAG }}/$CIDR_SPARE_STAG/g" {} +
find . -type f -name "*.yml" -exec sed -i -e "s/{{ CIDR_SPARE_PROD }}/$CIDR_SPARE_PROD/g" {} +
find . -type f -name "*.yml" -exec sed -i -e "s/{{ SUBNET02_CIDR_THIRD_OCTET }}/$SUBNET02_CIDR_THIRD_OCTET/g" {} +
