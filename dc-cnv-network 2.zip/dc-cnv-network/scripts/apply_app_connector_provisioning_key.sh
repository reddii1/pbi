#!/usr/bin/env bash

# Stop the running zpa-connector service
sudo systemctl stop zpa-connector

# Create a provisioning key file
sudo touch /opt/zscaler/var/provision_key
sudo chmod 644 /opt/zscaler/var/provision_key

# Paste in the provisioning key
echo "${provisioning-key}" | sudo tee /opt/zscaler/var/provision_key

# Restart zpa-connector service
sudo systemctl start zpa-connector