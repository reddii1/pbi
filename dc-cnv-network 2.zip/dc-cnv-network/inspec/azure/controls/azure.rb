## Azure Inspec Testing for Dynatrace Activegate (Sandbox) ##
title "Azure rb"

# Variables
env                           = input('env')
uksouth_location              = input('uksouth_location')
deploy_bastion                = input('deploy_bastion')
deploy_sql_mi                 = input('deploy_sql_mi')
deploy_fe03                   = input('deploy_fe03')
# Resrouce Groups
uksouth_rg_network            = input('uksouth_rg_network')
uksouth_rg_core               = input('uksouth_rg_core')
uksouth_rg_oms                = input('uksouth_rg_oms')

# Network
uksouth_vnet_name                   = input('uksouth_vnet_name')
uksouth_vnet_fe_address_space       = input('uksouth_vnet_fe_address_space')
uksouth_vnet_be_address_space       = input('uksouth_vnet_be_address_space')
uksouth_vnet_spare_address_space    = input('uksouth_vnet_spare_address_space')
uksouth_subnet_fe01_cidr            = input('uksouth_subnet_fe01_cidr')
uksouth_subnet_fe02_cidr            = input('uksouth_subnet_fe02_cidr')
uksouth_subnet_fe03_cidr            = input('uksouth_subnet_fe03_cidr')
uksouth_subnet_be01_cidr            = input('uksouth_subnet_be01_cidr')
uksouth_subnet_be02_cidr            = input('uksouth_subnet_be02_cidr')
uksouth_subnet_bastion_cidr         = input('uksouth_subnet_bastion_cidr')
uksouth_subnet_sql_mi_01_cidr       = input('uksouth_subnet_sql_mi_01_cidr')
uksouth_subnet_fe01_name            = input('uksouth_subnet_fe01_name')
uksouth_subnet_fe02_name            = input('uksouth_subnet_fe02_name')
uksouth_subnet_fe03_name            = input('uksouth_subnet_fe03_name')
uksouth_subnet_be01_name            = input('uksouth_subnet_be01_name')
uksouth_subnet_be02_name            = input('uksouth_subnet_be02_name')
uksouth_subnet_bastion_name         = input('uksouth_subnet_bastion_name')
uksouth_subnet_sql_mi_01_name       = input('uksouth_subnet_sql_mi_01_name')
uksouth_subnet_fe01_nsg             = input('uksouth_subnet_fe01_nsg')
uksouth_subnet_fe02_nsg             = input('uksouth_subnet_fe02_nsg')
uksouth_subnet_fe03_nsg             = input('uksouth_subnet_fe03_nsg')
uksouth_subnet_be01_nsg             = input('uksouth_subnet_be01_nsg')
uksouth_subnet_be02_nsg             = input('uksouth_subnet_be02_nsg')
uksouth_subnet_bastion_nsg          = input('uksouth_subnet_bastion_nsg')
uksouth_subnet_sql_mi_01_nsg        = input('uksouth_subnet_sql_mi_01_nsg')

# Resource Groups
control 'azurerm_resource_groups' do
  title 'Resource Group_network'
  desc 'Ensures Resource Groups exists'
  describe azurerm_resource_groups.where(name: uksouth_rg_network) do
    it { should exist }
  end
  describe azurerm_resource_groups.where(name: uksouth_rg_core) do
    it { should exist }
  end
  describe azurerm_resource_groups.where(name: uksouth_rg_oms) do
    it { should exist }
  end

end
# Virtual Networks
control 'azurerm_virtual_network' do
  title 'Virtual Networks'
  desc 'Ensures Virtual Networks exists'
  describe azurerm_virtual_network(resource_group: uksouth_rg_network, name: uksouth_vnet_name) do
    it { should exist }
    its('properties.provisioningState') { should cmp 'Succeeded' }
    its('location')  { should eq uksouth_location }
    its('address_space') { should eq [uksouth_vnet_fe_address_space,uksouth_vnet_be_address_space,uksouth_vnet_spare_address_space] }
  end
end

# Subnets
control 'uksouth_subnet_fe01' do
  title 'Subnets'
  desc 'Ensures Subnet exists'
  describe azurerm_subnet(resource_group: uksouth_rg_network, vnet: uksouth_vnet_name, name: uksouth_subnet_fe01_name) do
    it { should exist }
    its('properties.provisioningState') { should cmp 'Succeeded' }
    its('nsg') { should eq uksouth_subnet_fe01_nsg }
    its('address_prefix') {should eq uksouth_subnet_fe01_cidr}
  end
end
control 'uksouth_subnet_fe02' do
  title 'Subnets'
  desc 'Ensures Subnet exists'
  describe azurerm_subnet(resource_group: uksouth_rg_network, vnet: uksouth_vnet_name, name: uksouth_subnet_fe02_name) do
    it { should exist }
    its('properties.provisioningState') { should cmp 'Succeeded' }
    its('nsg') { should eq uksouth_subnet_fe02_nsg }
    its('address_prefix') {should eq uksouth_subnet_fe02_cidr}
  end
end
control 'uksouth_subnet_be01' do
  title 'Subnets'
  desc 'Ensures Subnet exists'
  describe azurerm_subnet(resource_group: uksouth_rg_network, vnet: uksouth_vnet_name, name: uksouth_subnet_be01_name) do
    it { should exist }
    its('properties.provisioningState') { should cmp 'Succeeded' }
    its('nsg') { should eq uksouth_subnet_be01_nsg }
    its('address_prefix') {should eq uksouth_subnet_be01_cidr}
  end
end
control 'uksouth_subnet_be02' do
  title 'Subnets'
  desc 'Ensures Subnet exists'
  describe azurerm_subnet(resource_group: uksouth_rg_network, vnet: uksouth_vnet_name, name: uksouth_subnet_be02_name) do
    it { should exist }
    its('properties.provisioningState') { should cmp 'Succeeded' }
    its('nsg') { should eq uksouth_subnet_be02_nsg }
    its('address_prefix') {should eq uksouth_subnet_be02_cidr}
  end
end

# Optional Subnets

control 'uksouth_subnet_bastion' do
  only_if { deploy_bastion == true }
  title 'Subnets'
  desc 'Ensures Subnet exists'
  describe azurerm_subnet(resource_group: uksouth_rg_network, vnet: uksouth_vnet_name, name: uksouth_subnet_bastion_name) do
    it { should exist }
    its('properties.provisioningState') { should cmp 'Succeeded' }
    its('nsg') { should eq uksouth_subnet_bastion_nsg }
    its('address_prefix') {should eq uksouth_subnet_bastion_cidr}
  end
end
control 'uksouth_subnet_sql_mi_01' do
  only_if { deploy_sql_mi == true }
  title 'Subnets'
  desc 'Ensures Subnet exists'
  describe azurerm_subnet(resource_group: uksouth_rg_network, vnet: uksouth_vnet_name, name: uksouth_subnet_sql_mi_01_name) do
    it { should exist }
    its('properties.provisioningState') { should cmp 'Succeeded' }
    its('nsg') { should eq uksouth_subnet_sql_mi_01_nsg }
    its('address_prefix') {should eq uksouth_subnet_sql_mi_01_cidr}
  end
end
control 'uksouth_subnet_fe03' do
  only_if { deploy_fe03 == true}
  title 'Subnets'
  desc 'Ensures Subnet exists'
  describe azurerm_subnet(resource_group: uksouth_rg_network, vnet: uksouth_vnet_name, name: uksouth_subnet_fe03_name) do
    it { should exist }
    its('properties.provisioningState') { should cmp 'Succeeded' }
    its('nsg') { should eq uksouth_subnet_fe03_nsg }
    its('address_prefix') {should eq uksouth_subnet_fe03_cidr}
  end
end