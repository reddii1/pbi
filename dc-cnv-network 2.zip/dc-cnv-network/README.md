[![Build Status](<https://dev.azure.com/dwpgovuk/>dc-cnv/_apis/build/status/dc-cnv-network?branchName=master)](<https://dev.azure.com/dwpgovuk/>dc-cnv/_build/latest?definitionId=185&branchName=master)

# Introduction

This project deploys the core infrastructure resources for the dc-cnv PDU.

First run the `setup_vars.sh` script to populate the tfvars and inspec input files, before running `deploy_pdu_sbox.sh` to deploy the sandbox environment. As well as creating the sandbox, it will create a **service connection** for the DWPCloudServices SPN, and create a **pipeline** which will trigger on commit to master branch, and setup a daily schedule to protect the environment from configuration drift via manual changes made in the portal.

## Prerequisites

- Teraform v1.1.7
- Docker (from self service)
- Azure CLI with azuredevops extension
- Access to the Shared Services Key Vault **kv-dwp-cds-dev-ss**
- This should be run by HCS DevOps engineer with the appropriate role assignments in Azure - PDU engineers won't be able to run it as they won't have the required permissions.
- You must have exported the zscaler certificate (use the utility in self service)
- The target subscription must be empty. If it isn't then all resources should be removed first, RBAC controls assigned at the subscription level and assocaited groups removed, and the security centre config removed (pricing and settings, email notifications)

## Getting Started

Uses Terraform v1.1.7 - dockerfile attached.

## Build and Test

Deploy from a docker container with the tools installed. To build navigate to the *docker* folder and type `bash build.sh`

>The first time you run the container you'll need to [add an SSH key and add it to your DevOps profile](https://docs.microsoft.com/en-us/azure/devops/repos/git/use-ssh-keys-to-authenticate?view=azure-devops). (use `ls ~/.ssh` to check if you already have one.  `ssh-keygen -C "firstname.lastname@dwpgovuk.onmicrosoft.com"` to create a key (accept all defaults).)
>
>When you have created a key and exit the container, commit the changes so they're still there next time you run it. `docker ps -a` to find the container id. `docker commit containerid azadmin`

Run the docker container `docker run -it -v ~/git:/git azadmin`

Run `az login` to authenticate against Azure.

Clone this dc-cnv-network repo, then naviagate to the scripts directory and run `bash setup_vars.sh`. This will subsctitue the relevant variables in `.tfvars, .yaml` and other key files with the correct values before you deploy.

### Script Variables

setup_vars.sh wil prompt you for:

- PDU lower case short name (dc-cnv, ch-pns, dw-ccs etc)
- 3rd octect of the **front end and back end address space** (from the *pdu address spaces uks* tab in the Azure IP Allocation Spreadsheet, address columns. Also shown in column I '*seed for calculations*'.)
- 3rd octet of the **sandbox spare ranges**
- 3rd octet of the **dev spare ranges**

![cidr](./img/ipspreadsheet.png "cidr")

run `bash deploy_pdu_sbox.sh`

> The deploy script must be run from the context of the scripts folder, otherwise some steps such as installing the correct version of terraform will fail

This script will

- Pick up the SPN credentials from Key Vault
- Create storage account for state if it doesn't already exist
- Install the version of terraform referenced in the *.tf_version* file
- Initialise Terraform
- Run the code and deploy the environment
- Create a pipeline with CI trigger, and daily schedule for sbox, dev and test.
- When the code is checked in after you've deployed the sandbox, it should run the pipeline to deploy dev and test.
- The pipelines will also run inspec tests to confirmm the deployment accurately reflects intended output.

## Architecture

The vNet will be deployed with 4 subnets, 2x front end subnets for proxy, application and integration servers, and 2x back end subnets for data and managment servers. The backend address IP Ranges are private to Azure, and cannot be used to route to DWP or AWS directly (some kind of proxying component will be required in the front end subnets.)

The blueprint also caters for the '*Modern Data Warehouse*" standard devloped by the Health Data Science team. There is a true/false selector in Terraform.tfvars to deploy this, and it will deploy all the resources needed for a SQL Managed Instance, plus Data Bricks networking requirements, plus a front end 03 subnet for an App Service Environment (and required networking).

There is also a selector to deploy a front-end-03 subnet on its own, if required.

There is a selctor to deploy Azure Bastion. This is set to false by default - usually it would only go in to sandbox, but it will be blocked by the '*Deny Public IP Addresses*' policy. This will need an exclusion before you can deploy Bastion, and this would usually be done by SRE post deployment.

The design leaves spare space from the IP allocations to allow additional subnets to be edited in to the terraform code if needed, as shown in grey in the diagram below.

![dc-cnv virtual network layout](./img/pdu-blueprint-v2.png "dc-cnv virtual network layout")

## Resources Deployed

![dc-cnv resource groups](./img/rgs.png "dc-cnv resource groups")

## Terraform Variables

If populated using the setup_vars.sh script, much of this will be calculated and automatically populated for you.

This deployment uses Terraform workspaces to represent environment: sbox, devt, test, stag, prod.

If you change one of the selectors (EG to deploy Azure Bastion) you must updated the equivilent in the inspec input file, or the pipeline will fail.

### PDU

>PDU is the first part of the subscription name representing directorate and deputy directorate, eg dc-cnv or DW-CCS, TS-HCS, CH-PNS

### Subscription id

>Complete the nested block for the PDU subscription IDs. Use  `var.subscription_id[terraform.workspace]` in templates to call the correct variable value.

### CIDR ranges for addrses space and subnets

>Address spaces are taken from the IP Allocation spread sheet, where each PDU has been pre-allocated IP Ranges.
>
>Front End 03 subnet range continues from Front End 02
>
>The additional SQL Managed Instances CIDR range is taken from the top of the data tier address space (BE01, "172.27.236.0/23"; new subnet = "172.27.236.224/27"). This is deployed if the *modern data warehouse* switch is selected. It will automatically deploy the subnet, plus the rules required for SQL MI.

![dc-cnv IP Allocations](./img/ipspreadsheet.png "dc-cnv IP Allocations")

### Shared services values

shared services values are used for peering networks and accessing the shared image gallery (where used)
