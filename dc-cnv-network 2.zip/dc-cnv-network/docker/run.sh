#!/bin/bash

docker run -it -v ${PWD}:/git azadmin
