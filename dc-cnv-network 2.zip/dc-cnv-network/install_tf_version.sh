# Update Terraform Version

terraform -v
TF_VERSION=$(cat .tf_version | awk '{$1=$1};1')
rm /usr/local/bin/terraform
wget https://releases.hashicorp.com/terraform/${TF_VERSION}/terraform_${TF_VERSION}_linux_amd64.zip --no-check-certificate && \
    unzip ./terraform_${TF_VERSION}_linux_amd64.zip -d /usr/local/bin/
rm ./terraform_${TF_VERSION}_linux_amd64.zip
terraform -v
