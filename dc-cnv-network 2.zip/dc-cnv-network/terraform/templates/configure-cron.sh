#!/bin/bash

set -e

LB_IP='${lb_ip}'

# Install Azure Cli
apt install python3-pip unzip -y
pip3 install azure-cli

# Login to azure
az login --identity

# create script.sh
cat > /home/azureuser/perf/script.sh << EOF
#!/bin/bash

set -ex

SIPP_EXIT_CODE=0
cd /home/azureuser/perf
sipp -sf dwpNearHup.xml $LB_IP -s 300 -t t1 -m 1 -trace_msg -trace_err
SIPP_EXIT_CODE=$?
if [ $SIPP_EXIT_CODE -gt 0 ]
then
  echo "sipp failed with exit code $SIPP_EXIT_CODE"
  touch /tmp/sipp.flag
else
  echo "sipp is working as expected"
  rm -f /tmp/sipp.flag
fi
EOF
chmod +x /home/azureuser/perf/script.sh

# Setup cronjob
cat > /tmp/azureuser <<EOF
*/5 * * * * /home/azureuser/perf/script.sh
EOF
cp /tmp/azureuser /var/spool/cron/crontabs
crontab -l -u azureuser
